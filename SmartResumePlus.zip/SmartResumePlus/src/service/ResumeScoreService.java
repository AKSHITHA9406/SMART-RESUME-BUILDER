package com.smartresume.service;

import com.smartresume.model.EducationEntry;
import com.smartresume.model.ExperienceEntry;
import com.smartresume.model.ProjectEntry;
import com.smartresume.model.Resume;
import com.smartresume.model.SkillEntry;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Simple scoring logic for SmartResume+.
 * Very "student style" and easy to explain in viva / report.
 */
public class ResumeScoreService {

    // Completeness out of 100 based on which sections are filled.
    public int calculateCompleteness(Resume resume) {
        int score = 0;

        if (resume.getPersonalInfo() != null) {
            score += 20;
        }
        if (!resume.getEducationList().isEmpty()) {
            score += 20;
        }
        if (!resume.getExperienceList().isEmpty()) {
            score += 20;
        }
        if (!resume.getProjectList().isEmpty()) {
            score += 20;
        }
        if (!resume.getSkillList().isEmpty()) {
            score += 20;
        }

        // keep it in [0, 100]
        if (score < 0) score = 0;
        if (score > 100) score = 100;
        return score;
    }

    // Very basic JD match: word overlap between JD and resume content.
    public int calculateMatchScore(Resume resume) {
        String jd = resume.getJobDescriptionText();
        if (jd == null || jd.trim().isEmpty()) {
            return 0;
        }

        // words in JD
        Set<String> jdWords = new HashSet<>(
                Arrays.asList(jd.toLowerCase().split("\\W+"))
        );
        jdWords.removeIf(String::isBlank);

        // collect some words from resume (skills + projects + experience)
        StringBuilder resumeText = new StringBuilder();
        for (SkillEntry s : resume.getSkillList()) {
            resumeText.append(" ").append(s.getName());
        }
        for (ProjectEntry p : resume.getProjectList()) {
            resumeText.append(" ").append(p.getTitle())
                    .append(" ").append(p.getTechStack())
                    .append(" ").append(p.getDescription());
        }
        for (ExperienceEntry e : resume.getExperienceList()) {
            resumeText.append(" ").append(e.getRole())
                    .append(" ").append(e.getCompany())
                    .append(" ").append(e.getDescription());
        }

        Set<String> resumeWords = new HashSet<>(
                Arrays.asList(resumeText.toString().toLowerCase().split("\\W+"))
        );
        resumeWords.removeIf(String::isBlank);

        if (jdWords.isEmpty()) {
            return 0;
        }

        int matchCount = 0;
        for (String w : jdWords) {
            if (resumeWords.contains(w)) {
                matchCount++;
            }
        }

        int score = (int) Math.round((matchCount * 100.0) / jdWords.size());
        if (score < 0) score = 0;
        if (score > 100) score = 100;
        return score;
    }
}
