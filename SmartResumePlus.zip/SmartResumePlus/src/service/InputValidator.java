package com.smartresume.service;

public class InputValidator {

    public static boolean isValidEmail(String email) {
        if (email == null) return false;
        email = email.trim();
        return !email.isEmpty() && email.contains("@") && email.contains(".");
    }

    public static boolean isValidPhone(String phone) {
        if (phone == null) return false;
        phone = phone.trim();
        // exactly 10 digits only
        return phone.matches("\\d{10}");
    }
}
