package com.smartresume.ui;

import javax.swing.SwingUtilities;

public class SmartResumeApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
