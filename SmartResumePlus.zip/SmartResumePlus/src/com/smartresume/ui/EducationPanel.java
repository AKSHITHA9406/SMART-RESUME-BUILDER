package com.smartresume.ui;
import com.smartresume.model.EducationEntry;
import com.smartresume.model.Resume;

import javax.swing.*;
import java.awt.*;

public class EducationPanel extends JPanel {

    private final Resume resume;

    private JComboBox<String> levelBox;
    private JTextField degreeField;
    private JTextField instituteField;
    private JTextField yearField;
    private JTextField cgpaField;

    private DefaultListModel<String> listModel;
    private JList<String> eduList;

    private JButton addOrSaveButton;
    private JButton editButton;
    private JButton deleteButton;

    private int editingIndex = -1; // -1 = adding new

    public EducationPanel(Resume resume) {
        this.resume = resume;
        initComponents();
        reloadExisting();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel levelLabel = new JLabel("Level:");
        JLabel degreeLabel = new JLabel("Class / Degree:");
        JLabel instituteLabel = new JLabel("School / College:");
        JLabel yearLabel = new JLabel("Year:");
        JLabel cgpaLabel = new JLabel("CGPA / %:");

        levelBox = new JComboBox<>(new String[] {"School", "College"});
        degreeField = new JTextField(20);
        instituteField = new JTextField(20);
        yearField = new JTextField(10);
        cgpaField = new JTextField(10);

        addOrSaveButton = new JButton("Add Education");
        editButton = new JButton("Edit Selected");
        deleteButton = new JButton("Delete Selected");

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(levelLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(levelBox, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(degreeLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(degreeField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(instituteLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(instituteField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(yearLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(yearField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(cgpaLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(cgpaField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel btnRow = new JPanel();
        btnRow.add(addOrSaveButton);
        btnRow.add(editButton);
        btnRow.add(deleteButton);
        formPanel.add(btnRow, gbc);

        // List
        listModel = new DefaultListModel<>();
        eduList = new JList<>(listModel);
        JScrollPane listScroll = new JScrollPane(eduList);
        listScroll.setBorder(BorderFactory.createTitledBorder("Education Entries"));

        add(formPanel, BorderLayout.NORTH);
        add(listScroll, BorderLayout.CENTER);

        // Listeners
        addOrSaveButton.addActionListener(e -> addOrSaveEducation());
        editButton.addActionListener(e -> loadSelectedForEdit());
        deleteButton.addActionListener(e -> deleteSelected());
    }

    private void reloadExisting() {
        listModel.clear();
        for (EducationEntry e : resume.getEducationList()) {
            listModel.addElement(e.toString());
        }
    }

    private void addOrSaveEducation() {
        String level = (String) levelBox.getSelectedItem();
        String degree = degreeField.getText().trim();
        String institute = instituteField.getText().trim();
        String year = yearField.getText().trim();
        String cgpa = cgpaField.getText().trim();

        if (degree.isEmpty() || institute.isEmpty() || year.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill degree/class, institute, and year.");
            return;
        }

        EducationEntry entry = new EducationEntry(level, degree, institute, year, cgpa);

        if (editingIndex == -1) {
            // add new
            resume.addEducation(entry);
            listModel.addElement(entry.toString());
        } else {
            // save edited
            resume.getEducationList().set(editingIndex, entry);
            listModel.set(editingIndex, entry.toString());
            editingIndex = -1;
            addOrSaveButton.setText("Add Education");
        }

        degreeField.setText("");
        instituteField.setText("");
        yearField.setText("");
        cgpaField.setText("");
    }

    private void loadSelectedForEdit() {
        int index = eduList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select an entry from the list to edit.");
            return;
        }

        EducationEntry entry = resume.getEducationList().get(index);
        editingIndex = index;

        levelBox.setSelectedItem(entry.getLevel());
        degreeField.setText(entry.getDegreeOrClass());
        instituteField.setText(entry.getInstitute());
        yearField.setText(entry.getYear());
        cgpaField.setText(entry.getCgpaOrPercent());

        addOrSaveButton.setText("Save Changes");
    }

    private void deleteSelected() {
        int index = eduList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select an entry to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete selected education?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            resume.getEducationList().remove(index);
            listModel.remove(index);
            if (editingIndex == index) {
                editingIndex = -1;
                addOrSaveButton.setText("Add Education");
            }
        }
    }
}
