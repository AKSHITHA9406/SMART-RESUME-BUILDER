package com.smartresume.ui;

import com.smartresume.model.Resume;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private Resume resume = new Resume();

    public MainFrame() {
        setTitle("SmartResume+ — Java Resume Builder");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        initUI();
    }

    private void initUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(63, 81, 181));

        JLabel titleLabel = new JLabel("SmartResume+", JLabel.LEFT);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 22f));

        JLabel subtitleLabel = new JLabel("Smart Resume Builder with Job Description Match", JLabel.LEFT);
        subtitleLabel.setForeground(new Color(220, 220, 255));

        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setOpaque(false);
        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        header.add(textPanel, BorderLayout.CENTER);
        header.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Personal Info", new PersonalInfoPanel(resume));
        tabs.addTab("Education", new EducationPanel(resume));
        tabs.addTab("Experience", new ExperiencePanel(resume));
        tabs.addTab("Projects", new ProjectPanel(resume));
        tabs.addTab("Skills", new SkillPanel(resume));
        tabs.addTab("Job Description", new JobDescriptionPanel(resume, tabs));
        tabs.addTab("Preview & Export", new PreviewPanel(resume));

        add(header, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
    }
}
