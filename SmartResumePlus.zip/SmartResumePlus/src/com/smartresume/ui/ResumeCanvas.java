package com.smartresume.ui;

import com.smartresume.model.EducationEntry;
import com.smartresume.model.ExperienceEntry;
import com.smartresume.model.PersonalInfo;
import com.smartresume.model.ProjectEntry;
import com.smartresume.model.Resume;
import com.smartresume.model.SkillEntry;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ResumeCanvas extends JPanel {

    private final Resume resume;

    public ResumeCanvas(Resume resume) {
        this.resume = resume;
        setPreferredSize(new Dimension(800, 900));
        setBackground(new Color(240, 240, 240));   // soft grey around page
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int pageWidth = 700;
        int pageX = Math.max(20, (getWidth() - pageWidth) / 2);
        int pageY = 25;
        int pageHeight = getHeight() - 50;

        // Shadow
        g2.setColor(new Color(0, 0, 0, 40));
        g2.fillRoundRect(pageX + 5, pageY + 5, pageWidth, pageHeight, 18, 18);

        // Page
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(pageX, pageY, pageWidth, pageHeight, 18, 18);
        g2.setColor(new Color(200, 200, 200));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(pageX, pageY, pageWidth, pageHeight, 18, 18);

        // ===== Header band =====
        int headerH = 80;
        g2.setColor(new Color(63, 81, 181));
        g2.fillRoundRect(pageX, pageY, pageWidth, headerH, 18, 18);

        int contentX = pageX + 40;
        int contentY = pageY + 32;
        int contentW = pageWidth - 80;

        PersonalInfo p = resume.getPersonalInfo();

        if (p != null) {
            // Name
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 26));
            drawString(g2, p.getFullName(), contentX, contentY);

            // Contact line
            contentY += 22;
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            String contact = p.getPhone() + "  •  " + p.getEmail();
            drawString(g2, contact, contentX, contentY);

            // Address + LinkedIn under header
            contentY = pageY + headerH + 30;
            g2.setColor(new Color(66, 66, 66));
            if (p.getAddress() != null && !p.getAddress().isBlank()) {
                drawString(g2, p.getAddress(), contentX, contentY);
                contentY += 18;
            }
            if (p.getLinkedIn() != null && !p.getLinkedIn().isBlank()) {
                g2.setColor(new Color(25, 118, 210));
                drawString(g2, "LinkedIn: " + p.getLinkedIn(), contentX, contentY);
                contentY += 24;
            }
        } else {
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 22));
            drawString(g2, "Name Not Entered", contentX, contentY);
            contentY = pageY + headerH + 30;
        }

        // light separator
        g2.setColor(new Color(224, 224, 224));
        g2.drawLine(contentX, contentY, contentX + contentW, contentY);
        contentY += 25;

        // ===== EDUCATION =====
        List<EducationEntry> school = new ArrayList<>();
        List<EducationEntry> college = new ArrayList<>();
        for (EducationEntry e : resume.getEducationList()) {
            if (e.getLevel() != null && e.getLevel().equalsIgnoreCase("School")) {
                school.add(e);
            } else {
                college.add(e);
            }
        }

        if (!school.isEmpty() || !college.isEmpty()) {
            contentY = drawSectionTitle(g2, "EDUCATION", contentX, contentY, contentW);

            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            g2.setColor(new Color(55, 71, 79));

            for (EducationEntry e : school) {
                contentY = drawEducationLine(g2, e, contentX, contentY);
            }
            for (EducationEntry e : college) {
                contentY = drawEducationLine(g2, e, contentX, contentY);
            }
            contentY += 10;
        }

        // ===== PROJECTS =====
        if (!resume.getProjectList().isEmpty()) {
            contentY = drawSectionTitle(g2, "PROJECTS", contentX, contentY, contentW);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            g2.setColor(new Color(55, 71, 79));

            for (ProjectEntry pr : resume.getProjectList()) {
                String titleLine = "• " + pr.getTitle();
                if (pr.getTechStack() != null && !pr.getTechStack().isBlank()) {
                    titleLine += "  [" + pr.getTechStack() + "]";
                }
                drawString(g2, titleLine, contentX, contentY);
                contentY += 16;

                if (pr.getDescription() != null && !pr.getDescription().isBlank()) {
                    contentY = drawWrappedText(g2, pr.getDescription(),
                            contentX + 18, contentY, contentW - 30);
                }
                contentY += 10;
            }
            contentY += 6;
        }

        // ===== EXPERIENCE =====
        if (!resume.getExperienceList().isEmpty()) {
            contentY = drawSectionTitle(g2, "EXPERIENCE", contentX, contentY, contentW);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            g2.setColor(new Color(55, 71, 79));

            for (ExperienceEntry ex : resume.getExperienceList()) {
                String titleLine = "• " + ex.getRole() + " — " + ex.getCompany();
                drawString(g2, titleLine, contentX, contentY);
                contentY += 16;

                String dur = ex.getDuration();
                if (dur != null && !dur.isBlank()) {
                    g2.setColor(new Color(117, 117, 117));
                    drawString(g2, "Duration: " + dur, contentX + 18, contentY);
                    contentY += 16;
                }

                if (ex.getDescription() != null && !ex.getDescription().isBlank()) {
                    g2.setColor(new Color(55, 71, 79));
                    contentY = drawWrappedText(g2, ex.getDescription(),
                            contentX + 18, contentY, contentW - 30);
                }
                contentY += 10;
            }
            contentY += 6;
        }

        // ===== SKILLS =====
        if (!resume.getSkillList().isEmpty()) {
            contentY = drawSectionTitle(g2, "SKILLS", contentX, contentY, contentW);

            int x = contentX;
            int yRow = contentY;
            int tagH = 22;

            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));

            for (SkillEntry s : resume.getSkillList()) {
                String name = s.getName();
                if (name == null || name.isBlank()) continue;

                int tagW = g2.getFontMetrics().stringWidth(name) + 22;
                if (x + tagW > contentX + contentW) {
                    x = contentX;
                    yRow += tagH + 6;
                }

                g2.setColor(new Color(227, 242, 253)); // tag fill
                g2.fillRoundRect(x, yRow - tagH + 5, tagW, tagH, 15, 15);

                g2.setColor(new Color(21, 101, 192)); // border + text
                g2.drawRoundRect(x, yRow - tagH + 5, tagW, tagH, 15, 15);
                g2.drawString(name, x + 10, yRow);

                x += tagW + 8;
            }
        }

        g2.dispose();
    }

    private int drawEducationLine(Graphics2D g2, EducationEntry e, int x, int y) {
        g2.setColor(new Color(55, 71, 79));
        String main = e.getDegreeOrClass() + " — " + e.getInstitute();
        drawString(g2, main, x, y);
        y += 16;

        String details = e.getYear();
        if (e.getCgpaOrPercent() != null && !e.getCgpaOrPercent().isBlank()) {
            details += "   |   " + e.getCgpaOrPercent();
        }
        g2.setColor(new Color(117, 117, 117));
        drawString(g2, details, x + 18, y);
        y += 22;

        return y;
    }

    // section title with more spacing so bar doesn't overlap text
    private int drawSectionTitle(Graphics2D g2, String title, int x, int y, int width) {
        y += 10; // space before section
        g2.setColor(new Color(63, 81, 181));
        g2.fillRect(x, y, 90, 3); // small blue bar above
        y += 18;

        g2.setColor(new Color(38, 50, 56));
        g2.setFont(new Font("SansSerif", Font.BOLD, 15));
        g2.drawString(title, x, y);
        y += 8;

        g2.setColor(new Color(224, 224, 224));
        g2.drawLine(x, y, x + width, y); // light grey line under heading
        return y + 16; // a bit of space before content
    }

    private void drawString(Graphics2D g2, String text, int x, int y) {
        if (text == null) return;
        g2.drawString(text, x, y);
    }

    // word-wrap helper for descriptions
    private int drawWrappedText(Graphics2D g2, String text, int x, int y, int maxWidth) {
        if (text == null || text.isBlank()) return y;
        FontMetrics fm = g2.getFontMetrics();
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();

        for (String w : words) {
            String test = (line.length() == 0) ? w : line + " " + w;
            int wPixels = fm.stringWidth(test);
            if (wPixels > maxWidth) {
                g2.drawString(line.toString(), x, y);
                y += fm.getHeight();
                line = new StringBuilder(w);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (!line.isEmpty()) {
            g2.drawString(line.toString(), x, y);
            y += fm.getHeight();
        }
        return y;
    }
}
