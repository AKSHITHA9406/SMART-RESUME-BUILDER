package com.smartresume.ui;

import com.smartresume.model.Resume;

import javax.swing.*;
import java.awt.*;

public class JobDescriptionPanel extends JPanel {

    private final Resume resume;
    private final JTabbedPane tabs;   // to switch to Preview tab
    private JTextArea jdArea;
    private JButton finishButton;

    public JobDescriptionPanel(Resume resume, JTabbedPane tabs) {
        this.resume = resume;
        this.tabs = tabs;
        initComponents();
        loadExisting();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        jdArea = new JTextArea(15, 40);
        jdArea.setLineWrap(true);
        jdArea.setWrapStyleWord(true);

        finishButton = new JButton("Finish & Go to Preview");

        add(new JScrollPane(jdArea), BorderLayout.CENTER);
        add(finishButton, BorderLayout.SOUTH);

        finishButton.addActionListener(e -> {
            String text = jdArea.getText().trim();
            resume.setJobDescriptionText(text);
            JOptionPane.showMessageDialog(this, "Job description saved!");

            // move to Preview tab (index 6 in our order)
            if (tabs != null) {
                tabs.setSelectedIndex(6);
            }
        });
    }

    private void loadExisting() {
        String text = resume.getJobDescriptionText();
        if (text != null) {
            jdArea.setText(text);
        }
    }
}
