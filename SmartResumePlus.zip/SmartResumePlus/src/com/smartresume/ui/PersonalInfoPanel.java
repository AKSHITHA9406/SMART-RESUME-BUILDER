package com.smartresume.ui;

import com.smartresume.model.PersonalInfo;
import com.smartresume.model.Resume;
import com.smartresume.service.InputValidator;

import javax.swing.*;
import java.awt.*;

public class PersonalInfoPanel extends JPanel {

    private final Resume resume;

    private JTextField nameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField addressField;
    private JTextField linkedInField;

    private JButton saveButton;
    private JButton editButton;

    public PersonalInfoPanel(Resume resume) {
        this.resume = resume;
        initComponents();
        loadExistingInfo();
    }

    private void initComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("Full Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel phoneLabel = new JLabel("Phone (10 digits):");
        JLabel addressLabel = new JLabel("Address:");
        JLabel linkedInLabel = new JLabel("LinkedIn URL:");

        nameField = new JTextField(25);
        emailField = new JTextField(25);
        phoneField = new JTextField(25);
        addressField = new JTextField(25);
        linkedInField = new JTextField(25);

        saveButton = new JButton("Save Personal Info");
        editButton = new JButton("Edit Existing Info");

        saveButton.addActionListener(e -> savePersonalInfo());
        editButton.addActionListener(e -> setEditable(true));

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        add(nameField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        add(emailLabel, gbc);
        gbc.gridx = 1;
        add(emailField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        add(phoneLabel, gbc);
        gbc.gridx = 1;
        add(phoneField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        add(addressLabel, gbc);
        gbc.gridx = 1;
        add(addressField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        add(linkedInLabel, gbc);
        gbc.gridx = 1;
        add(linkedInField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        add(saveButton, gbc);

        row++;
        gbc.gridy = row;
        add(editButton, gbc);
    }

    private void savePersonalInfo() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();
        String linkedIn = linkedInField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name cannot be empty.");
            return;
        }
        if (!InputValidator.isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email.");
            return;
        }
        if (!InputValidator.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Phone must be 10 digits.");
            return;
        }

        PersonalInfo info = new PersonalInfo(name, email, phone, address, linkedIn);
        resume.setPersonalInfo(info);

        JOptionPane.showMessageDialog(this, "Personal info saved!");
        setEditable(false);
    }

    private void loadExistingInfo() {
        PersonalInfo info = resume.getPersonalInfo();
        if (info != null) {
            nameField.setText(info.getFullName());
            emailField.setText(info.getEmail());
            phoneField.setText(info.getPhone());
            addressField.setText(info.getAddress());
            linkedInField.setText(info.getLinkedIn());
            setEditable(false); // start as read-only if data exists
        } else {
            setEditable(true);  // first time, editable
        }
    }

    private void setEditable(boolean editable) {
        nameField.setEditable(editable);
        emailField.setEditable(editable);
        phoneField.setEditable(editable);
        addressField.setEditable(editable);
        linkedInField.setEditable(editable);

        saveButton.setEnabled(editable);
        editButton.setEnabled(!editable);
    }
}
