package com.smartresume.ui;

import com.smartresume.model.Resume;
import com.smartresume.service.ResumeScoreService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class PreviewPanel extends JPanel {

    private final Resume resume;
    private final ResumeCanvas canvas;
    private final ResumeScoreService scoreService = new ResumeScoreService();

    private JProgressBar completenessBar;
    private JProgressBar matchBar;
    private JLabel tipsLabel;

    public PreviewPanel(Resume resume) {
        this.resume = resume;
        this.canvas = new ResumeCanvas(resume);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Top buttons
        JPanel topPanel = new JPanel();
        JButton previewButton = new JButton("Refresh Preview");
        JButton exportPngButton = new JButton("Export as PNG");
        topPanel.add(previewButton);
        topPanel.add(exportPngButton);

        // Center: resume canvas inside scroll pane
        JScrollPane scrollPane = new JScrollPane(canvas);

        // Bottom: score bars + tips placed a bit lower
        JPanel scoresPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        completenessBar = new JProgressBar(0, 100);
        completenessBar.setStringPainted(true);
        matchBar = new JProgressBar(0, 100);
        matchBar.setStringPainted(true);

        scoresPanel.add(new JLabel("Completeness Score:"));
        scoresPanel.add(completenessBar);
        scoresPanel.add(new JLabel("JD Match Score:"));
        scoresPanel.add(matchBar);

        tipsLabel = new JLabel(" ", SwingConstants.CENTER);

        JPanel bottomContent = new JPanel(new BorderLayout());
        bottomContent.add(scoresPanel, BorderLayout.NORTH);
        bottomContent.add(tipsLabel, BorderLayout.CENTER);
        bottomContent.setBorder(new EmptyBorder(10, 40, 25, 40)); // pushes panel a bit down

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.add(bottomContent, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(southWrapper, BorderLayout.SOUTH);

        // Button actions
        previewButton.addActionListener(e -> refreshPreview());
        exportPngButton.addActionListener(e -> exportAsPng());
    }

    private void refreshPreview() {
        canvas.repaint();

        int completeness = scoreService.calculateCompleteness(resume);
        int match = scoreService.calculateMatchScore(resume);

        completenessBar.setValue(completeness);
        completenessBar.setString(completeness + "%");
        matchBar.setValue(match);
        matchBar.setString(match + "%");

        String tip;
        if (completeness < 50) {
            tip = "Tip: Add more education, projects or experience to strengthen your resume.";
        } else if (match < 50) {
            tip = "Tip: Add some skills mentioned in the job description (only if relevant).";
        } else {
            tip = "Great! Your resume looks quite strong for this job description.";
        }
        tipsLabel.setText(tip);
    }

    private void exportAsPng() {
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        if (w <= 0 || h <= 0) {
            JOptionPane.showMessageDialog(this, "Please click 'Refresh Preview' first.");
            return;
        }

        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        canvas.paint(g2);
        g2.dispose();

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save Resume as PNG");
        int result = chooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                File out = chooser.getSelectedFile();
                if (!out.getName().toLowerCase().endsWith(".png")) {
                    out = new File(out.getAbsolutePath() + ".png");
                }
                ImageIO.write(img, "png", out);
                JOptionPane.showMessageDialog(this, "PNG exported successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error exporting PNG: " + ex.getMessage());
            }
        }
    }
}
