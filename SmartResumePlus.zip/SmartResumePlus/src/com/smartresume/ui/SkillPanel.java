package com.smartresume.ui;

import com.smartresume.model.Resume;
import com.smartresume.model.SkillEntry;

import javax.swing.*;
import java.awt.*;

public class SkillPanel extends JPanel {

    private final Resume resume;

    private JTextField skillField;
    private DefaultListModel<String> listModel;
    private JList<String> skillList;

    private JButton addOrSaveButton;
    private JButton editButton;
    private JButton deleteButton;

    private int editingIndex = -1;

    public SkillPanel(Resume resume) {
        this.resume = resume;
        initComponents();
        reloadExisting();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        JLabel skillLabel = new JLabel("Skill:");
        skillField = new JTextField(20);

        addOrSaveButton = new JButton("Add Skill");
        editButton = new JButton("Edit Selected");
        deleteButton = new JButton("Delete Selected");

        top.add(skillLabel);
        top.add(skillField);
        top.add(addOrSaveButton);
        top.add(editButton);
        top.add(deleteButton);

        listModel = new DefaultListModel<>();
        skillList = new JList<>(listModel);
        JScrollPane scroll = new JScrollPane(skillList);
        scroll.setBorder(BorderFactory.createTitledBorder("Skills"));

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        addOrSaveButton.addActionListener(e -> addOrSaveSkill());
        editButton.addActionListener(e -> loadSelectedForEdit());
        deleteButton.addActionListener(e -> deleteSelected());
    }

    private void reloadExisting() {
        listModel.clear();
        for (SkillEntry s : resume.getSkillList()) {
            listModel.addElement(s.toString());
        }
    }

    private void addOrSaveSkill() {
        String skill = skillField.getText().trim();
        if (skill.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Skill cannot be empty.");
            return;
        }

        SkillEntry entry = new SkillEntry(skill);

        if (editingIndex == -1) {
            resume.addSkill(entry);
            listModel.addElement(entry.toString());
        } else {
            resume.getSkillList().set(editingIndex, entry);
            listModel.set(editingIndex, entry.toString());
            editingIndex = -1;
            addOrSaveButton.setText("Add Skill");
        }

        skillField.setText("");
    }

    private void loadSelectedForEdit() {
        int index = skillList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select a skill to edit.");
            return;
        }

        SkillEntry entry = resume.getSkillList().get(index);
        editingIndex = index;
        skillField.setText(entry.getName());

        addOrSaveButton.setText("Save Changes");
    }

    private void deleteSelected() {
        int index = skillList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select a skill to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete selected skill?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            resume.getSkillList().remove(index);
            listModel.remove(index);
            if (editingIndex == index) {
                editingIndex = -1;
                addOrSaveButton.setText("Add Skill");
            }
        }
    }
}
