package com.smartresume.ui;

import com.smartresume.model.ProjectEntry;
import com.smartresume.model.Resume;

import javax.swing.*;
import java.awt.*;

public class ProjectPanel extends JPanel {

    private final Resume resume;

    private JTextField titleField;
    private JTextField techField;
    private JTextArea descArea;

    private DefaultListModel<String> listModel;
    private JList<String> projList;

    private JButton addOrSaveButton;
    private JButton editButton;
    private JButton deleteButton;

    private int editingIndex = -1;

    public ProjectPanel(Resume resume) {
        this.resume = resume;
        initComponents();
        reloadExisting();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Project Title:");
        JLabel techLabel = new JLabel("Tech Stack:");
        JLabel descLabel = new JLabel("Description:");

        titleField = new JTextField(20);
        techField = new JTextField(20);
        descArea = new JTextArea(4, 20);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);

        addOrSaveButton = new JButton("Add Project");
        editButton = new JButton("Edit Selected");
        deleteButton = new JButton("Delete Selected");

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(titleLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(techLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(techField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(descLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(new JScrollPane(descArea), gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel btnRow = new JPanel();
        btnRow.add(addOrSaveButton);
        btnRow.add(editButton);
        btnRow.add(deleteButton);
        formPanel.add(btnRow, gbc);

        listModel = new DefaultListModel<>();
        projList = new JList<>(listModel);
        JScrollPane scroll = new JScrollPane(projList);
        scroll.setBorder(BorderFactory.createTitledBorder("Projects"));

        add(formPanel, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        addOrSaveButton.addActionListener(e -> addOrSaveProject());
        editButton.addActionListener(e -> loadSelectedForEdit());
        deleteButton.addActionListener(e -> deleteSelected());
    }

    private void reloadExisting() {
        listModel.clear();
        for (ProjectEntry pr : resume.getProjectList()) {
            listModel.addElement(pr.toString());
        }
    }

    private void addOrSaveProject() {
        String title = titleField.getText().trim();
        String tech = techField.getText().trim();
        String desc = descArea.getText().trim();

        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Project title cannot be empty.");
            return;
        }

        ProjectEntry entry = new ProjectEntry(title, tech, desc);

        if (editingIndex == -1) {
            resume.addProject(entry);
            listModel.addElement(entry.toString());
        } else {
            resume.getProjectList().set(editingIndex, entry);
            listModel.set(editingIndex, entry.toString());
            editingIndex = -1;
            addOrSaveButton.setText("Add Project");
        }

        titleField.setText("");
        techField.setText("");
        descArea.setText("");
    }

    private void loadSelectedForEdit() {
        int index = projList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select a project to edit.");
            return;
        }

        ProjectEntry entry = resume.getProjectList().get(index);
        editingIndex = index;

        titleField.setText(entry.getTitle());
        techField.setText(entry.getTechStack());
        descArea.setText(entry.getDescription());

        addOrSaveButton.setText("Save Changes");
    }

    private void deleteSelected() {
        int index = projList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select a project to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete selected project?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            resume.getProjectList().remove(index);
            listModel.remove(index);
            if (editingIndex == index) {
                editingIndex = -1;
                addOrSaveButton.setText("Add Project");
            }
        }
    }
}
