package com.smartresume.model;

public class EducationEntry {

    private String level;           // "School" or "College"
    private String degreeOrClass;   // e.g., "Class 10", "B.Tech CSE"
    private String institute;
    private String year;
    private String cgpaOrPercent;

    // Updated constructor (5 arguments)
    public EducationEntry(String level, String degreeOrClass, String institute, String year, String cgpaOrPercent) {
        this.level = level;
        this.degreeOrClass = degreeOrClass;
        this.institute = institute;
        this.year = year;
        this.cgpaOrPercent = cgpaOrPercent;
    }

    // Getters
    public String getLevel() {
        return level;
    }

    public String getDegreeOrClass() {
        return degreeOrClass;
    }

    public String getInstitute() {
        return institute;
    }

    public String getYear() {
        return year;
    }

    public String getCgpaOrPercent() {
        return cgpaOrPercent;
    }

    @Override
    public String toString() {
        return "[" + level + "] " + degreeOrClass + " - " + institute + " (" + year + "), " + cgpaOrPercent;
    }
}

