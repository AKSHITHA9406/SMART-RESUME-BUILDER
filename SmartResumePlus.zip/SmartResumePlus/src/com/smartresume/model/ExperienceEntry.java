package com.smartresume.model;

public class ExperienceEntry {

    private String role;
    private String company;
    private String duration;     // e.g., "Jun 2024 – Aug 2024"
    private String description;  // brief about work

    public ExperienceEntry(String role, String company, String duration, String description) {
        this.role = role;
        this.company = company;
        this.duration = duration;
        this.description = description;
    }

    public String getRole() { return role; }
    public String getCompany() { return company; }
    public String getDuration() { return duration; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return role + " @ " + company + " (" + duration + ")";
    }
}
