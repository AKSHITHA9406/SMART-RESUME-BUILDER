package com.smartresume.model;

import java.util.ArrayList;
import java.util.List;

public class Resume {

    private PersonalInfo personalInfo;
    private List<EducationEntry> educationList = new ArrayList<>();
    private List<ExperienceEntry> experienceList = new ArrayList<>();
    private List<ProjectEntry> projectList = new ArrayList<>();
    private List<SkillEntry> skillList = new ArrayList<>();
    private String jobDescriptionText; // from JD tab later

    public PersonalInfo getPersonalInfo() {
        return personalInfo;
    }

    public void setPersonalInfo(PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    public List<EducationEntry> getEducationList() {
        return educationList;
    }

    public void addEducation(EducationEntry entry) {
        educationList.add(entry);
    }

    public List<ExperienceEntry> getExperienceList() {
        return experienceList;
    }

    public void addExperience(ExperienceEntry entry) {
        experienceList.add(entry);
    }

    public List<ProjectEntry> getProjectList() {
        return projectList;
    }

    public void addProject(ProjectEntry entry) {
        projectList.add(entry);
    }

    public List<SkillEntry> getSkillList() {
        return skillList;
    }

    public void addSkill(SkillEntry entry) {
        skillList.add(entry);
    }

    public String getJobDescriptionText() {
        return jobDescriptionText;
    }

    public void setJobDescriptionText(String jobDescriptionText) {
        this.jobDescriptionText = jobDescriptionText;
    }
}
