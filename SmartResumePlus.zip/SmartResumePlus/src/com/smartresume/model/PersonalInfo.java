package com.smartresume.model;

public class PersonalInfo {
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private String linkedIn;

    public PersonalInfo(String fullName, String email, String phone, String address, String linkedIn) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.linkedIn = linkedIn;
    }

    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public String getLinkedIn() { return linkedIn; }
}
