package com.smartresume.model;

public class ProjectEntry {

    private String title;
    private String techStack;
    private String description;

    public ProjectEntry(String title, String techStack, String description) {
        this.title = title;
        this.techStack = techStack;
        this.description = description;
    }

    public String getTitle() { return title; }
    public String getTechStack() { return techStack; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return title + " [" + techStack + "]";
    }
}
