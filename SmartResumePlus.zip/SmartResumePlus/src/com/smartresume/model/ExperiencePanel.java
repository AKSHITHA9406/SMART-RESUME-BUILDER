package com.smartresume.ui;

import com.smartresume.model.ExperienceEntry;
import com.smartresume.model.Resume;

import javax.swing.*;
import java.awt.*;

public class ExperiencePanel extends JPanel {

    private final Resume resume;

    private JTextField roleField;
    private JTextField companyField;
    private JTextField durationField;
    private JTextArea descArea;

    private DefaultListModel<String> listModel;
    private JList<String> expList;

    private JButton addOrSaveButton;
    private JButton editButton;
    private JButton deleteButton;

    private int editingIndex = -1;

    public ExperiencePanel(Resume resume) {
        this.resume = resume;
        initComponents();
        reloadExisting();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel roleLabel = new JLabel("Role / Position:");
        JLabel companyLabel = new JLabel("Company:");
        JLabel durationLabel = new JLabel("Duration:");
        JLabel descLabel = new JLabel("Description:");

        roleField = new JTextField(20);
        companyField = new JTextField(20);
        durationField = new JTextField(15);
        descArea = new JTextArea(4, 20);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);

        addOrSaveButton = new JButton("Add Experience");
        editButton = new JButton("Edit Selected");
        deleteButton = new JButton("Delete Selected");

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(roleLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(roleField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(companyLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(companyField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(durationLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(durationField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(descLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(new JScrollPane(descArea), gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel btnRow = new JPanel();
        btnRow.add(addOrSaveButton);
        btnRow.add(editButton);
        btnRow.add(deleteButton);
        formPanel.add(btnRow, gbc);

        listModel = new DefaultListModel<>();
        expList = new JList<>(listModel);
        JScrollPane listScroll = new JScrollPane(expList);
        listScroll.setBorder(BorderFactory.createTitledBorder("Experience Entries"));

        add(formPanel, BorderLayout.NORTH);
        add(listScroll, BorderLayout.CENTER);

        addOrSaveButton.addActionListener(e -> addOrSaveExperience());
        editButton.addActionListener(e -> loadSelectedForEdit());
        deleteButton.addActionListener(e -> deleteSelected());
    }

    private void reloadExisting() {
        listModel.clear();
        for (ExperienceEntry ex : resume.getExperienceList()) {
            listModel.addElement(ex.toString());
        }
    }

    private void addOrSaveExperience() {
        String role = roleField.getText().trim();
        String company = companyField.getText().trim();
        String duration = durationField.getText().trim();
        String desc = descArea.getText().trim();

        if (role.isEmpty() || company.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Role and company cannot be empty.");
            return;
        }

        ExperienceEntry entry = new ExperienceEntry(role, company, duration, desc);

        if (editingIndex == -1) {
            resume.addExperience(entry);
            listModel.addElement(entry.toString());
        } else {
            resume.getExperienceList().set(editingIndex, entry);
            listModel.set(editingIndex, entry.toString());
            editingIndex = -1;
            addOrSaveButton.setText("Add Experience");
        }

        roleField.setText("");
        companyField.setText("");
        durationField.setText("");
        descArea.setText("");
    }

    private void loadSelectedForEdit() {
        int index = expList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select an experience to edit.");
            return;
        }

        ExperienceEntry entry = resume.getExperienceList().get(index);
        editingIndex = index;

        roleField.setText(entry.getRole());
        companyField.setText(entry.getCompany());
        durationField.setText(entry.getDuration());
        descArea.setText(entry.getDescription());

        addOrSaveButton.setText("Save Changes");
    }

    private void deleteSelected() {
        int index = expList.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Select an experience to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete selected experience?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            resume.getExperienceList().remove(index);
            listModel.remove(index);
            if (editingIndex == index) {
                editingIndex = -1;
                addOrSaveButton.setText("Add Experience");
            }
        }
    }
}
